import React from "react";

const ThemeToggle = ({ toggleTheme }) => {
  return (
    <div style={{ marginBottom: "20px", textAlign: "center" }}>
      <button
        onClick={toggleTheme}
        style={{
          background: "#007bff",
          color: "#fff",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
        }}
      >
        Toggle Theme
      </button>
    </div>
  );
};

export default ThemeToggle;
