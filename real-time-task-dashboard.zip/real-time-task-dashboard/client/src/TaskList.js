import React from "react";

const TaskList = ({ tasks, onDeleteTask }) => {
  return (
    <ul style={{ listStyleType: "none", padding: 0 }}>
      {tasks.length === 0 ? (
        <li style={{ textAlign: "center", color: "#777" }}>No tasks yet!</li>
      ) : (
        tasks.map((task) => (
          <li
            key={task.id}
            style={{
              border: "1px solid #ddd",
              marginBottom: "10px",
              padding: "15px",
              borderRadius: "8px",
              background: "#fff",
              boxShadow: "0 2px 4px rgba(0,0,0,0.1)"
            }}
          >
            <h3 style={{ margin: "0 0 10px" }}>{task.title}</h3>
            <p>{task.description}</p>
            <p><strong>Deadline:</strong> {task.deadline}</p>
            <p><strong>Assigned to:</strong> {task.assignee}</p>
            <button
              onClick={() => onDeleteTask(task.id)}
              style={{
                marginTop: "10px",
                background: "#dc3545",
                color: "#fff",
                padding: "8px 12px",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
              }}
            >
              Delete
            </button>
          </li>
        ))
      )}
    </ul>
  );
};

export default TaskList;
