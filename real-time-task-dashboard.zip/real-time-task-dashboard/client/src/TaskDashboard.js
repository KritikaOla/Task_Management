import React, { useState, useEffect } from "react";
import io from "socket.io-client";
import TaskForm from "./TaskForm";
import TaskList from "./TaskList";

const socket = io("http://localhost:5000", {
  transports: ["websocket"],
  withCredentials: true,
});

const TaskDashboard = () => {
  const [tasks, setTasks] = useState([]);

  useEffect(() => {
    socket.on("loadTasks", (loadedTasks) => {
      setTasks(loadedTasks);
    });

    socket.on("taskUpdated", (updatedTasks) => {
      setTasks(updatedTasks);
    });

    return () => {
      socket.off("loadTasks");
      socket.off("taskUpdated");
    };
  }, []);

  const addTask = (task) => {
    socket.emit("addTask", task);
  };

  const deleteTask = (id) => {
    socket.emit("deleteTask", id);
  };

  return (
    <div style={{ maxWidth: "600px", margin: "0 auto" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>Task Dashboard (Real-time)</h1>

      {/* Task Form */}
      <TaskForm onAddTask={addTask} />

      {/* Task List */}
      <TaskList tasks={tasks} onDeleteTask={deleteTask} />
    </div>
  );
};

export default TaskDashboard;
