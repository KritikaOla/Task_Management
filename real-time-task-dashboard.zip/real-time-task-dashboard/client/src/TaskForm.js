import React, { useState } from "react";

const TaskForm = ({ onAddTask }) => {
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    deadline: "",
    assignee: ""
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setNewTask((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!newTask.title.trim()) return;

    const taskToSend = {
      ...newTask,
      id: Date.now(),
    };

    onAddTask(taskToSend);
    setNewTask({
      title: "",
      description: "",
      deadline: "",
      assignee: ""
    });
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "grid", gap: "10px", marginBottom: "20px" }}>
      <input
        type="text"
        name="title"
        placeholder="Title"
        value={newTask.title}
        onChange={handleChange}
        style={inputStyle}
        required
      />
      <textarea
        name="description"
        placeholder="Description"
        value={newTask.description}
        onChange={handleChange}
        style={inputStyle}
      />
      <input
        type="date"
        name="deadline"
        value={newTask.deadline}
        onChange={handleChange}
        style={inputStyle}
      />
      <input
        type="text"
        name="assignee"
        placeholder="Assignee"
        value={newTask.assignee}
        onChange={handleChange}
        style={inputStyle}
      />
      <button type="submit" style={buttonStyle}>Add Task</button>
    </form>
  );
};

const inputStyle = {
  padding: "10px",
  border: "1px solid #ccc",
  borderRadius: "5px",
};

const buttonStyle = {
  background: "#28a745",
  color: "#fff",
  padding: "10px",
  border: "none",
  borderRadius: "5px",
  cursor: "pointer",
};

export default TaskForm;
