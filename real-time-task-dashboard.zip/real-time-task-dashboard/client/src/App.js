import React, { useState } from "react";
import { ThemeProvider } from "styled-components";
import TaskDashboard from "./TaskDashboard";
import ThemeToggle from "./ThemeToggle";

const lightTheme = {
  background: "#f9f9f9",
  color: "#333",
};

const darkTheme = {
  background: "#333",
  color: "#f9f9f9",
};

function App() {
  const [theme, setTheme] = useState(lightTheme);

  const toggleTheme = () => {
    setTheme(theme === lightTheme ? darkTheme : lightTheme);
  };

  return (
    <ThemeProvider theme={theme}>
      <div
        style={{
          backgroundColor: theme.background,
          color: theme.color,
          minHeight: "100vh",
          padding: "20px",
        }}
      >
        <ThemeToggle toggleTheme={toggleTheme} />
        <TaskDashboard />
      </div>
    </ThemeProvider>
  );
}

export default App;
