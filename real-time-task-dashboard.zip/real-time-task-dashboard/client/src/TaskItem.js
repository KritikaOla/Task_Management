import React from "react";

const TaskItem = ({ task, onDeleteTask }) => {
  return (
    <li>
      {task.title}
      <button onClick={() => onDeleteTask(task.id)}>Delete</button>
    </li>
  );
};

export default TaskItem;
